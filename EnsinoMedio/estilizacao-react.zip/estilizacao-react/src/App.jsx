import { useState } from 'react';
import Home from './screens/Home.jsx';

function App() {

  return (
    <Home />
  )
}

export default App
