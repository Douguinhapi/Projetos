import React from 'react';

export default function TextBig({ label }) {
  return (
    <h1 className="text-big">
      {label}
    </h1>
  );
}
  